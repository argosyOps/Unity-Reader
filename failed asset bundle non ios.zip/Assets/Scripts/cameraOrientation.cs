﻿using UnityEngine;
using System.Collections;

//public enum PortraitMode{
//	off,on
//};

public class cameraOrientation : MonoBehaviour {

	public int Portrait;



//	public PortraitMode portraitMode;


}
