﻿using UnityEngine;
using System.Collections;

public class orientation : MonoBehaviour {

	public int width;
	public int portraitTrigger;



	
	// Update is called once per frame
	void Update () {




		// Change scene camera size based on orientation
		if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft || Input.deviceOrientation == DeviceOrientation.LandscapeRight || Input.GetKeyDown ("l")) {
			UseLandscapeLeftLayout();
		}
//		else if (Input.deviceOrientation == DeviceOrientation.Portrait || Input.deviceOrientation == DeviceOrientation.PortraitUpsideDown || Input.GetKeyDown ("p")  ) {
//			UsePortraitLayout();
//
//		} 


	}



	public void UsePortraitLayout(){
	//	Camera.main.orthographicSize = 9.54F;

		GameObject leftPort = GameObject.Find("leftNavigatePortrait");
		leftPort.collider.enabled=true;
//		leftPort.renderer.enabled=true;
		
		GameObject rightPort = GameObject.Find("rightNavigatePortrait");
		rightPort.collider.enabled=true;
//		rightPort.renderer.enabled=true;

		GameObject leftPortZoomOut = GameObject.Find("leftNavigatePortraitZoomOut");
		leftPortZoomOut.collider.enabled=false;

		
		GameObject rightPortZoomOut = GameObject.Find("rightNavigatePortraitZoomOut");
		rightPortZoomOut.collider.enabled=false;


		GameObject leftLand = GameObject.Find("leftNavigateLandscape");
		leftLand.collider.enabled=false;
//		leftLand.renderer.enabled=false;
		
		GameObject rightLand = GameObject.Find("rightNavigateLandscape");
		rightLand.collider.enabled=false;
//		rightLand.renderer.enabled=false;



	}

	public void UseLandscapeLeftLayout(){
	//	Camera.main.orthographicSize = 4.82F;

		GameObject leftPort = GameObject.Find("leftNavigatePortrait");
		leftPort.collider.enabled=false;
	//	leftPort.renderer.enabled=false;

		GameObject rightPort = GameObject.Find("rightNavigatePortrait");
		rightPort.collider.enabled=false;
	//	rightPort.renderer.enabled=false;

		GameObject leftPortZoomOut = GameObject.Find("leftNavigatePortraitZoomOut");
		leftPortZoomOut.collider.enabled=false;
	
		
		GameObject rightPortZoomOut = GameObject.Find("rightNavigatePortraitZoomOut");
		rightPortZoomOut.collider.enabled=false;
	

		GameObject leftLand = GameObject.Find("leftNavigateLandscape");
		leftLand.collider.enabled=true;
	//	leftLand.renderer.enabled=true;
		
		GameObject rightLand = GameObject.Find("rightNavigateLandscape");
		rightLand.collider.enabled=true;
	//	rightLand.renderer.enabled=true;



	}

	public void UsePortraitLayoutZoomOut(){
		//	Camera.main.orthographicSize = 4.82F;
		
		GameObject leftPort = GameObject.Find("leftNavigatePortrait");
		leftPort.collider.enabled=false;
		//	leftPort.renderer.enabled=false;
		
		GameObject rightPort = GameObject.Find("rightNavigatePortrait");
		rightPort.collider.enabled=false;
		//	rightPort.renderer.enabled=false;
		
		GameObject leftPortZoomOut = GameObject.Find("leftNavigatePortraitZoomOut");
		leftPortZoomOut.collider.enabled=true;
		
		
		GameObject rightPortZoomOut = GameObject.Find("rightNavigatePortraitZoomOut");
		rightPortZoomOut.collider.enabled=true;
		
		
		GameObject leftLand = GameObject.Find("leftNavigateLandscape");
		leftLand.collider.enabled=false;
		//	leftLand.renderer.enabled=true;
		
		GameObject rightLand = GameObject.Find("rightNavigateLandscape");
		rightLand.collider.enabled=false;
		//	rightLand.renderer.enabled=true;
		
		
		
	}




}
