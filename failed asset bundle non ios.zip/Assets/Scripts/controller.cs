﻿using UnityEngine;
using System.Collections;

public class controller : MonoBehaviour {

	string playing = null;
	static int Direction = 2;
	private float cameraZoom;
	float aniLength = 0;

	public int pageNum = 0;
	public int portraitTrigger;



	void Start () {
		

		playing = animation.clip.name;
		Length ();
		
		
		if (Direction == 1) {
			
			animation[playing].time = aniLength;
			Backward ();
		}
		
		
		
	}
	
	
	
	// Update is called once per frame
	void Update () {
		
		
		
		
		//Controls
		if (Input.GetKeyDown ("left")) {
			Backward();
		}
		
		if (Input.GetKeyDown ("right")) {
			Forward();
		}
		
		//End of frame trigger
		if (animation[playing].normalizedTime >= 0.90F && Direction == 2) {
			audioFadeOut();
		}

		//End of frame audio fade out
		if (animation[playing].normalizedTime >= 0.99F && Direction == 2) {
			nextPage();
		}
		
		// Turn off change scene camera size based trigger
		if (cameraZoom >= 8.87 && portraitTrigger == 1) {


		}


		
	}
	
	void FixedUpdate() {

		cameraZoom = Camera.main.orthographicSize;

		// Change scene camera size based trigger

		if ( portraitTrigger == 1 && cameraZoom <= 8.87) {
			portraitTriggerZoomOut();
		}

		// Change scene camera size based trigger

		if ( portraitTrigger == 0 && cameraZoom >= 4.82) {
			portraitTriggerZoomIn();
		}
		
		
	}



	public void Stopper() {
		//Stopping Script
		foreach (AnimationState state in animation) {
			state.speed = 0F;
			Direction = 0;
		}




	}


	//Start Frame event
	void frameStart() {
		if (Direction == 1) {
			lastPage();
		}
	}
	
	
	


	public void Backward() {
		foreach (AnimationState state in animation) {
			state.speed = -1.0F;
			Direction = 1;

			if (GameObject.Find("HotSpotPrefab(Clone)") != null )
			{
				GameObject Hot = GameObject.Find("HotSpotPrefab(Clone)");
				Hot.GetComponent<hotSpot>().fadeOutani();
			}
		}
	}

	public void Forward() {
		foreach (AnimationState state in animation) {
			state.speed = 1.0F;
			Direction = 2;

			if (GameObject.Find("HotSpotPrefab(Clone)") != null )
			{
				GameObject Hot = GameObject.Find("HotSpotPrefab(Clone)");
				Hot.GetComponent<hotSpot>().fadeOutani();
			}

		}
	}
	
	//Page Transition Audio Fadeout
	void audioFadeOut() {
		GameObject fadingAudio = GameObject.Find ("Page");
		fadingAudio.GetComponent<audioPlay> ().background1_fadeout();
		fadingAudio.GetComponent<audioPlay> ().background2_fadeout();
	}


	//Page Transition next page
	void nextPage() {
		Destroy (GameObject.FindWithTag("Page"));
		Destroy (GameObject.FindWithTag("Audio"));
		if (Application.levelCount - 1 <= pageNum + 1) {
			Application.LoadLevelAdditive ("page1");	
		} else {
			Application.LoadLevelAdditive ("page"+(pageNum+1));		
		}



	}

	//Page Transition previous page
	void lastPage() {


		Destroy (GameObject.FindWithTag("Page"));
		Destroy (GameObject.FindWithTag("Audio"));

		if (pageNum - 1 != 0) {
						Application.LoadLevelAdditive ("page" + (pageNum - 1));
				} else {
			Application.LoadLevelAdditive ("page2");
		}


	}

	//Length of Clip
	void Length() {
		aniLength = animation[playing].length;

	}

	//Generate HotSpot
	public void HotSpotCreation(){
		if (Direction == 2) {
						GameObject hot = GameObject.Find ("Hot Spot Placement");
						hot.GetComponent<hotSpotInstantiate> ().HotSpotCreate ();
				}
		}

	//Portrait Trigger Turn on
	public void portraitTriggerOn() {

		//Trigger Portrait mode
		if (Input.deviceOrientation == DeviceOrientation.Portrait || Input.deviceOrientation == DeviceOrientation.PortraitUpsideDown || Input.GetKeyDown ("p")) {
						portraitTrigger = 1;
						Debug.Log ("on");
			GameObject navOn = GameObject.Find ("Main Camera");
			navOn.GetComponent<orientation> ().UsePortraitLayoutZoomOut ();

		} else if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft || Input.deviceOrientation == DeviceOrientation.LandscapeRight || Input.GetKeyDown ("l")) {
			portraitTrigger = 0;
			Debug.Log ("off");

		}




	}

	public void portraitTriggerOff() {
		
		//Trigger Portrait mode
		portraitTrigger = 0;
		Debug.Log ("off Portrait mode");
		GameObject navOn = GameObject.Find ("Main Camera");
		navOn.GetComponent<orientation> ().UsePortraitLayout ();
	}


	//Portrait Trigger Camera Zoom Out
	void portraitTriggerZoomOut() {
		Camera.main.orthographicSize += 16f * Time.deltaTime;

	}

	//Landscape Trigger Camera Zoom Out
	void portraitTriggerZoomIn() {
		Camera.main.orthographicSize -= 16f * Time.deltaTime;
		
	}


}