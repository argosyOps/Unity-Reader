﻿using UnityEngine;
using System.Collections;

public class raycaster : MonoBehaviour {

	public int PortraitPublic;
	RaycastHit hit;


	void Update() {
		Vector3 forward = transform.TransformDirection(Vector3.forward) * 1000;
		Debug.DrawRay(transform.position, forward, Color.green);

		if (Physics.Raycast (transform.position, forward, out hit)) {
			raycastHit ();


			}


	}
		

	void raycastHit() {

		//Get value of gameobject in raycast collision
		string other = hit.collider.gameObject.name;
		GameObject panelHit = GameObject.Find(other);
		PortraitPublic = panelHit.GetComponent<cameraOrientation> ().Portrait;



		if (PortraitPublic == 1) {
			
			GameObject hitActive = GameObject.Find ("Page");
			hitActive.GetComponent<controller> ().portraitTriggerOn();
			Debug.Log ("Portait Public On");

				}

		if (PortraitPublic == 0) {
			
			GameObject hitActive = GameObject.Find ("Page");
			hitActive.GetComponent<controller> ().portraitTriggerOff();
			Debug.Log ("Portait Public Off");
			
		}
	}


	}

