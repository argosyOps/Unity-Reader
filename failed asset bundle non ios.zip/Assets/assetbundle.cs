﻿using UnityEngine;
using System.Collections;

public class assetbundle : MonoBehaviour {

	private string url = "http://medikidz.com/Test-Area/assetbundles/files/Resource.unity3d";

	IEnumerator Start () {
		// Start a download of the given URL
		WWW www = WWW.LoadFromCacheOrDownload (url, 1);
		
		// Wait for download to complete
		yield return www;
		
		// Load and retrieve the AssetBundle
		AssetBundle bundle = www.assetBundle;
		
		// Load the object asynchronously
		AssetBundleRequest request = bundle.LoadAsync ("Page3", typeof(GameObject));
		
		// Wait for completion
		yield return request;
		
		// Get the reference to the loaded object
		GameObject obj = request.asset as GameObject;


	}

}
